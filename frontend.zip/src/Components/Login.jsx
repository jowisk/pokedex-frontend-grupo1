import React from 'react'

const Login = () => {
  return (
        <div className="">
            hola
        </div>
  )
}

export default Login