module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    screens: {
      'mobile-s': '320px',
      'iphone12pro': '320px'
    },
    extend: {},
  },
  plugins: [],
}